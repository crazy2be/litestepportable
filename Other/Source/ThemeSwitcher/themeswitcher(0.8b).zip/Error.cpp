#include "Error.h"

void Error(string ErrorMessage) {
    MessageBox(NULL, ErrorMessage.c_str(), "ERROR!", MB_OK | MB_ICONERROR);
}

void Warning(string WarningMessage) {
    MessageBox(NULL, WarningMessage.c_str(), "Warning!", MB_OK | MB_ICONWARNING);
}

void Info(string Information) {
    MessageBox(NULL, Information.c_str(), "Information:", MB_OK | MB_ICONINFORMATION);
}

string GetErrorString(DWORD ErrorCode) {
    char ErrorMsgChar [1024];
    LPSTR ErrorMessage = ErrorMsgChar;
    FormatMessage(
        FORMAT_MESSAGE_FROM_SYSTEM,
        NULL,
        ErrorCode,
        0,
        ErrorMessage,
        1024,
        NULL);
    string StrErrorMessage = ErrorMessage;
    return StrErrorMessage;
}
