#include <windows.h>
#include <string>

using namespace std;

void Error(string ErrorMessage);
void Warning(string WarningMessage);
void Info(string Information);

string GetErrorString(DWORD ErrorCode);
