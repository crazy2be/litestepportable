#include "Error.h"
#include "InstallTheme.h"
#include "GetSettings.h"

void InstallTheme(string ThemePath) {
    /*HWND EditWindow;
    EditWindow = CreateWindow(
        "static",
        "Extracting Archive...",
        WS_VISIBLE, // Styles
        CW_USEDEFAULT,
        CW_USEDEFAULT,
        150,
        50,
        HWND_DESKTOP,
        NULL,
        NULL,
        NULL);*/
    //Edit_SetText(EditWindow, ThemePath.c_str());
    ExtractTheme(ThemePath);
    /*Edit_SetText(EditWindow, "Adding theme to list...");
    
    DestroyWindow(EditWindow);*/
}

void ExtractTheme(string ThemePath) {
    if (ThemePath != "") {
        ostringstream CommandLine;
        CommandLine << "7z.exe x -o\"" << GetValue("ThemesDir").c_str();
        CommandLine << "\" -t\"zip\" \"" << ThemePath.c_str() << "\" *\0";
        
        PROCESS_INFORMATION SevenZipProcInfo;
        /* Seven Zip Startup Structure */
        _STARTUPINFOA SZSS; 
        /* To (help) prevent unexplainable segfaults */
        ZeroMemory(&SZSS, sizeof(SZSS)); 
        SZSS.cb = sizeof(SZSS);
        SZSS.lpTitle = "Extracting Archive...";
        if (GetValue("Show Extracting Console") != "true") {
            SZSS.dwFlags = STARTF_USESHOWWINDOW;
            SZSS.wShowWindow = SW_HIDE;
        }
        //char* CommandLineCharP = const_cast<char*>(CommandLine.c_str()); // Converts the std::string into a char*
        
        LPTSTR CommandLineLp;
        CommandLineLp = const_cast<char*>(CommandLine.str().c_str());
        LPCTSTR SevenZipExeName = "7z.exe";
        if (!CreateProcess(
            SevenZipExeName,
            CommandLineLp,
            NULL,
            NULL,
            true,
            NORMAL_PRIORITY_CLASS,
            NULL,
            NULL,
            &SZSS,
            &SevenZipProcInfo)) {
                DWORD LastError = GetLastError();
                char ErrorMsgChar [1024];
                LPSTR ErrorMessage = ErrorMsgChar;
                FormatMessage(
                    FORMAT_MESSAGE_FROM_SYSTEM,
                    NULL,
                    LastError,
                    0,
                    ErrorMessage,
                    1024,
                    NULL);
                    string StrErrorMessage = ErrorMessage;
                    Error("Error occured while attempting to extract theme:\n"
                        + StrErrorMessage
                        + "\n"
                        + "Make sure 7z.exe and 7z.dll are in the same directory as\n"
                        + "This program.");
                    return;
        }
    }
}

string PromptForThemeFile() {
    char CurrentWD [MAX_PATH];
    _getcwd(CurrentWD, MAX_PATH);
    CHAR FileName[512] = "";
    OPENFILENAME ThemeOpen;
    ZeroMemory(&ThemeOpen, sizeof(ThemeOpen));
    ThemeOpen.lStructSize = sizeof(ThemeOpen);
    ThemeOpen.lpstrTitle = "Select a Theme To install...";
    ThemeOpen.lpstrFilter = "Litestep Themes (*.lsz)\0*.lsz\0Zip Archives (*.zip)\0*.zip\0";
    ThemeOpen.nFilterIndex = 1;
    ThemeOpen.Flags = OFN_HIDEREADONLY | OFN_PATHMUSTEXIST | OFN_FILEMUSTEXIST;
    ThemeOpen.lpstrFile = FileName;
    ThemeOpen.nMaxFile = sizeof(FileName);
    ThemeOpen.lpstrInitialDir = NULL;
    
    
    if (GetOpenFileName(&ThemeOpen)) {
        string FileNameStr = FileName;
        SetCurrentDirectory(CurrentWD);
        return FileNameStr;
    }

    Error("Something went wrong.\n(Or you may have pressed the cancel button)");
    return "";
}

/*void UpdateInfoLoop(void* nothing) {
    LPTSTR ConsoleText;
    DWORD MaxLength = 64000;
    COORD ConsoleStartPoint;
    ConsoleStartPoint.X = 0;
    ConsoleStartPoint.Y = 0;
    LPDWORD CharsRead;
    while (true) {
        ReadConsoleOutputCharacter(
            SevenZipConsoleHandle,
            ConsoleText,
            MaxLength,
            ConsoleStartPoint,
            CharsRead);
        //Error("Right before setting the text...");
        Edit_SetText(EditWindow, ConsoleText);
        Sleep(10);
    }
}*/
