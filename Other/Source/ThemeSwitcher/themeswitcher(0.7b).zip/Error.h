#include <windows.h>
#include <string>

using namespace std;

void Error(string ErrorMessage);
