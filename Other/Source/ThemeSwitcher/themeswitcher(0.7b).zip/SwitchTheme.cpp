#include "SwitchTheme.h"
#include "GetSettings.h"
#include "Error.h"

void SwitchTheme(string ThemeName, bool Prompt) {
    int SwitchResult;
    if (Prompt) {
        SwitchResult = MessageBox(NULL, ThemeName.c_str(), "Switch Theme?", MB_YESNO);
    } else {
        SwitchResult = IDYES;
    }
    if (SwitchResult == IDYES) { //The user clicked yes
        ifstream GetTheme;
        string line;
        string EndText;
        GetTheme.open((GetValue("ThemesDir") + "Themeselect.rc").c_str());
        if (GetTheme.is_open()) {
            while (!GetTheme.eof()) {
                getline ( GetTheme, line );
                if (line.substr(0, 8) == "ThemeDir") {
                    line = "ThemeDir \"$ThemesDir$";
                    line += ThemeName;
                    line += "\\\"";
                }
                EndText += line;
                EndText += "\n";
            }
            GetTheme.close();
        } else {
            Error("Bah can't open file :(");
        }
        ofstream SetTheme;
        SetTheme.open((GetValue("ThemesDir") + "Themeselect.rc").c_str());
        if (SetTheme.is_open()) {
            SetTheme << EndText.substr(0, EndText.length()-1);
            SetTheme.close();
        } else {
            Error("Bah can't open file :(");
        }
        ShellExecute(NULL, "open", GetValue("Litestep").c_str(), "!recycle", NULL, SW_SHOWNORMAL);
        if (ThemeName != GetValue("DefaultTheme")) {
            Sleep(GetIntValue("DefaultThemePromptTimeout"));
            string ThemeMsg = "Switch back to the default theme? (";
            ThemeMsg += GetValue("DefaultTheme");
            ThemeMsg += ")\n";
            ThemeMsg += "[You may want to do this if the theme has loading errors]";
            if (MessageBox(NULL, ThemeMsg.c_str(),
                "Switch to the default?",
                MB_YESNO) == IDYES) {
                    SwitchTheme(GetValue("DefaultTheme"), false);
                }
        }
    }
}
