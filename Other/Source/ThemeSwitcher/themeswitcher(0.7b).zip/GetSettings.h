#include <fstream>
#include <string>

using namespace std;
/* Declare Functions */
string GetValue(string ValueToGet);
int GetIntValue(string ValueToGet);
string GetDefaultValue(string ValueToGet);
