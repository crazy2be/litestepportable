#include "ArgProc.h"
#include "SwitchTheme.h"

void ArgProcessing(string Args) {
    MessageBox(NULL, NULL, Args.c_str(), NULL);
    if (Args.substr(0,7) == "/switch") {
        int FirstQuote = Args.find("\"")+1;
        string AfterFirstQuote = Args.substr(FirstQuote, Args.length());
        int SecondQuote = AfterFirstQuote.find("\"");
        SwitchTheme(Args.substr(FirstQuote, SecondQuote));
        exit( EXIT_SUCCESS );
    }
}

