#include <windows.h>
#include <string>


using namespace std;
/*  Declare Windows procedure  */
LRESULT CALLBACK WindowProcedure (HWND, UINT, WPARAM, LPARAM);

/* Declare other functions */
void GetInstalledThemes();
void SwitchTheme(string ThemeName);
void Error(string ErrorMessage);

/*  Make the class name into a global variable  */
char szClassName[ ] = "WindowsApp";
HWND ThemeListhwnd;
HWND InstallThemehwnd;
HWND SwitchThemehwnd;

/* The array of theme names */
string ThemeNames[50];
