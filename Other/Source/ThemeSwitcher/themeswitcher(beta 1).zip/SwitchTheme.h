#include <fstream>
#include <string>
#include <windows.h>

using namespace std;

void SwitchTheme(string ThemeName);
