#include "Error.h"

void Error(string ErrorMessage) {
    MessageBox(NULL, ErrorMessage.c_str(), "ERROR!", MB_OK);
}
