/* This source file contains all the global variables. */
#include <windows.h>
//#ifndef _Global_Vars_
//#define _Global_Vars_
extern HWND GlobalThemeMgrMainWindowHWND;
extern HINSTANCE GlobalhThisInstance;
extern HWND GlobalStatushwnd;
//#endif

