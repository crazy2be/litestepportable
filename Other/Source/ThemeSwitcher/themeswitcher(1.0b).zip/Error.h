#include <windows.h>
#include <windowsx.h>
#include <string>

using namespace std;

void Error(string ErrorMessage);
void Warning(string WarningMessage);
void Info(string Information);
void Status(string NewStatus);

string GetErrorString(DWORD ErrorCode);
