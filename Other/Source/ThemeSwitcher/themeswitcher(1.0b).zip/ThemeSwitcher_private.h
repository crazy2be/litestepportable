/* THIS FILE WILL BE OVERWRITTEN BY DEV-C++ */
/* DO NOT EDIT ! */

#ifndef THEMESWITCHER_PRIVATE_H
#define THEMESWITCHER_PRIVATE_H

/* VERSION DEFINITIONS */
#define VER_STRING	"1.0.0.1"
#define VER_MAJOR	1
#define VER_MINOR	0
#define VER_RELEASE	0
#define VER_BUILD	1
#define COMPANY_NAME	"crazy2be"
#define FILE_VERSION	"1.0b"
#define FILE_DESCRIPTION	"A Theme Switcher/Installer/Manager for LiteStep!"
#define INTERNAL_NAME	"ThemeSwitcher"
#define LEGAL_COPYRIGHT	"GPL"
#define LEGAL_TRADEMARKS	"GPL"
#define ORIGINAL_FILENAME	"ThemeSwitcher.exe"
#define PRODUCT_NAME	"ThemeSwitcher"
#define PRODUCT_VERSION	"1.0b"

#endif /*THEMESWITCHER_PRIVATE_H*/
