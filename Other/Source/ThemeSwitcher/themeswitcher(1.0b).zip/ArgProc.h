#include <windows.h>
#include <string>

using namespace std;

/* Functions in the cpp file... */
void ArgProcessing(string Args);
