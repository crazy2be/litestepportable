#include "ArgProc.h"
#include "SwitchTheme.h"

void ArgProcessing(string Args) {
    MessageBox(NULL, Args.c_str(), "Command-line Aurguments:", NULL);
    if (Args.substr(0,7) == "/switch") {
        int FirstQuote = Args.find("\"")+1;
        string AfterFirstQuote = Args.substr(FirstQuote, Args.length());
        int SecondQuote = AfterFirstQuote.find("\"");
        SwitchTheme(Args.substr(FirstQuote, SecondQuote), false);
        exit( EXIT_SUCCESS );
    }
}

