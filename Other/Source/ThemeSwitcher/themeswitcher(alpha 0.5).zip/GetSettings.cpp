#include "GetSettings.h"

int GetIntValue(string ValueToGet) {
    return atoi(GetValue(ValueToGet).c_str());
}
string GetValue(string ValueToGet) {
    string line;
    //string value;
    string setting;
    int equalsign;
    try {
        ifstream SetRead ("Settings.ini");
        if (SetRead.is_open()) {
            while (! SetRead.eof()) {
                getline (SetRead, line);
                //cout << line << endl;
                if (line[0] == ';') {
                    
                } else {
                    equalsign = line.find('=');
                    setting = line.substr(0, equalsign);
                    //value = line.substr((equalsign+1), line.length());
                    if (setting == ValueToGet) {
                        return line.substr((equalsign+1), line.length());
                    }
                }
           }
        }
        SetRead.close();
        return "";
    } catch (...) {
        return "";
    }
}
