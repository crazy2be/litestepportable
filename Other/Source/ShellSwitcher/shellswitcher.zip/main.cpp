// c2b.cpp : Defines the entry point for the console application.
//

#include <cstdlib>
#include <iostream>
#include <fstream>
#include <windows.h>
#include <windef.h>
#include <direct.h>
#include <psapi.h>
#include <string>

using namespace std;

/*Define Methods*/
bool ExplorerRunning();
bool LitestepRunning();
string GetProcessName( DWORD processID );
void PromptAction();
void NoPromptAction();
bool KillExplorer();
bool KillLitestep();
bool StartExplorer();
bool StartLitestep();
string GetSettingValue(string SettingToFind);
int GetSettingIntValue(string SettingToFind);
void SaveDriveData();
char GetDriveLetter();

/*Define Global Variables*/
bool ExplorerIsRunning;
bool LitestepIsRunning;
DWORD LitestepPID;
DWORD ExplorerPID;
int PromptLevel;


int main(int argc, char *argv[])
{
    // Set Global Variables
    ExplorerIsRunning = ExplorerRunning();
    LitestepIsRunning = LitestepRunning();
    // Check what the PromptLevel is set to and make sure it is valid
    if (GetSettingIntValue("PromptLevel") > 0 && GetSettingIntValue("PromptLevel") < 4) {
        PromptLevel = GetSettingIntValue("PromptLevel");
        PromptAction();
    } else {
        MessageBox(NULL, "\"PromptLevel\" is set to an invalid setting!\nDefaulting to allways prompting ( setting 2 )\nDefine it in Settings.ini, \"PromptLevel=[1-3]\"", "ERROR:", MB_OK);
        PromptLevel = 3;
        PromptAction();
    }
    return EXIT_SUCCESS;
}

void PromptAction() {  
    // The string to hold the console input
	string WhatToDo;
	// If bolth shells are running...
	if (ExplorerIsRunning && LitestepIsRunning) {
        if (PromptLevel > 1) {
		   if (MessageBox(NULL, "Bolth shells are active. Kill Litestep\nor Explorer?\n(Yes for Explorer, No for Litestep)", "Choose shell to kill", MB_YESNO) == IDYES) {
               KillExplorer();
           } else {
               KillLitestep();
           }
          } else {
             KillExplorer();
          }
    // If (only) explorer is running
	} else if (ExplorerIsRunning) {
        if (PromptLevel > 2) {
		   if (MessageBox(NULL, "Explorer is active. Kill Explorer and start Litestep?", "Kill Explorer & start Litestep?", MB_YESNO) == IDYES) {
              KillExplorer();
              StartLitestep();
           } else {
              exit( EXIT_SUCCESS );
           }
        } else {
           KillExplorer();
           StartLitestep();
        }
    // If (only) Litestep is running
	} else if (LitestepIsRunning) {
        if (PromptLevel > 2) {
		    if (MessageBox(NULL, "Litestep is active. Kill Litestep and start Explorer?", "Kill Litestep & start Explorer?", MB_YESNO) == IDYES) {
                KillLitestep();
                StartExplorer();
            } else {
                exit( EXIT_SUCCESS );
            }
        } else {
           KillLitestep();
           StartExplorer();
        }
    // If nothing is running...
	} else {
        if (PromptLevel > 1) {
	    	if (MessageBox(NULL, "Neither Shell is Active. Start Litestep or Explorer?\n(Yes for Litestep, no for Explorer)", "Start Litestep or Explorer?", MB_YESNO) == IDYES) {
                StartLitestep();
            } else {
                StartExplorer();
            }
        } else {
            StartLitestep();
        }
	}
}

bool KillLitestep() {
     // Terminating Litestep
     HANDLE LitestepHandle = OpenProcess(PROCESS_ALL_ACCESS, FALSE, LitestepPID);
     TerminateProcess(LitestepHandle, EXIT_SUCCESS);
    return false;
}
bool KillExplorer() {
     // Terminating Explorer
     HANDLE LitestepHandle = OpenProcess(PROCESS_ALL_ACCESS, FALSE, ExplorerPID);
     TerminateProcess(LitestepHandle, EXIT_FAILURE);
    return false;
}
bool StartLitestep() {
     // Starting Litestep
     SaveDriveData();
     ShellExecute( NULL, "open", "Litestep.exe", NULL, NULL, SW_SHOW);
    return false;
}
bool StartExplorer() {
     // Starting Explorer
     ShellExecute( NULL, "open", "Explorer.exe", NULL, "C:\\", SW_SHOW);
    return false;
}
bool ExplorerRunning() {
    DWORD aProcesses[1024], cbNeeded, cProcesses;
    
    unsigned int i;
    // Gets a list of running processes by PID
    EnumProcesses( aProcesses, sizeof(aProcesses), &cbNeeded );
    
    cProcesses = cbNeeded / sizeof(DWORD);
    // does a for loop for each process
    for ( i = 0; i < cProcesses; i++ ) {
        // Mackes sure the array is valid
        if( aProcesses[i] != 0 ) {
            // Match found!
            if (GetProcessName(aProcesses[i]) == "explorer.exe") {
                ExplorerPID = aProcesses[i];
                return true;
            }
        }
    }
    return false;
}

bool LitestepRunning() {
    DWORD aProcesses[1024], cbNeeded, cProcesses;
    
    unsigned int i;
    // Gets a list of running processes by PID
    EnumProcesses( aProcesses, sizeof(aProcesses), &cbNeeded );
    
    cProcesses = cbNeeded / sizeof(DWORD);
    // does a for loop for each process
    for ( i = 0; i < cProcesses; i++ ) {
        // Mackes sure the array is valid
        if( aProcesses[i] != 0 ) {
            // Match found!
            if (GetProcessName(aProcesses[i]) == "litestep.exe") {
                LitestepPID = aProcesses[i];
                return true;
            }
        }
    }
    return false;
}

string GetProcessName( DWORD processID )
{
	CHAR szProcessName[MAX_PATH] = "<unknown>";

	// Get a handle to the process.
	HANDLE hProcess = OpenProcess( PROCESS_QUERY_INFORMATION | PROCESS_VM_READ, FALSE, processID );

	// Get the process name.
	if (NULL != hProcess )
	{
		HMODULE hMod;
		DWORD cbNeeded;

		if ( EnumProcessModules( hProcess, &hMod, sizeof(hMod), &cbNeeded) )
			GetModuleBaseNameA( hProcess, hMod, szProcessName, sizeof(szProcessName)/sizeof(TCHAR) );
	}

	// Convert the process name to lowercase
	for (size_t i = 0; i <= strlen(szProcessName); i++)
		szProcessName[i] = tolower(szProcessName[i]);

    // Close the handle to the process
	CloseHandle( hProcess );

    // Return the process name
	return string(szProcessName);
}

string GetSettingValue(string SettingToFind) {
       string line;
       string Setting;
       string Value;
       ifstream SetReader;
       // Open the settings file for reading
       SetReader.open("Settings.ini");
       // Make sure it opened successfully
       if (SetReader.is_open()) {
          // While it's not the end of the file...
          while (! SetReader.eof()) {
                // Get the next line
                getline (SetReader, line);
                // Make sure it's not a comment line
                if (line[0] == ';') {
                   
                } else {
                // Get the "setting" (part before the "=")
                Setting = line.substr(0, line.find("="));
                if (Setting == SettingToFind) {
                    // If it Matches, return the part after the "="
                    return line.substr((line.find("=")+1), line.length());
                    }
                }
                }
          // Close the file to allow other applications access
          SetReader.close();
       } else {
          // There was an error :(
          MessageBox(NULL, "Error occured reading settings.ini", "ERROR:", MB_OK);
       }
       return "";
}
       
int GetSettingIntValue(string SettingToFind) {
    // Do the normal function, but convert it to an int
    return atoi(GetSettingValue(SettingToFind).c_str());
}

void SaveDriveData() {
     char disk = GetDriveLetter();
     ofstream DriveWriter;
     // Open the file for writing
     DriveWriter.open("Drive.rc");
     // If it was successfull...
     if (DriveWriter.is_open()) {
         // Write to the file...
         DriveWriter << ";AUTOMATICLY GENERATED FILE." << endl;
         DriveWriter << ";(any edits will be lost)" << endl;
         DriveWriter << "LSD  \"" << disk << ":\\\"" << endl;
     } else {
         // There was an error :(
         MessageBox(NULL, "ERROR WRITING TO DRIVE.RC\nThe application will now terminate", "ERROR!", MB_OK);
         system("PAUSE");
         exit( EXIT_FAILURE );
     }
     DriveWriter.close();
}

char GetDriveLetter() {
     /* Get the drive letter numerical representation
      * (1 = A, 2 = B, etc), and convert it to an ANSI
      * Character, like A, that we can use. 
      */
     return _getdrive() + 0x40;
}
